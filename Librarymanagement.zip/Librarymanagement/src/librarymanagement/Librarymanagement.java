/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarymanagement;

/**
 *
 * @author ASUS
 */
public class Librarymanagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        login d= new login();
        d.setVisible(true);
        d.setSize(1080,620);
        
    }
    
}
